// A simple Java program to demonstrate the use of reflection 
import java.lang.reflect.Method; 
import java.lang.reflect.Field; 
import java.lang.reflect.Constructor;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.ArrayList;

public class ReflectionClassesMethods
{ 
    public static void main(String args[]) throws Exception 
    { 
        Library libObj = new Library();
        Book bkObj = new Book("tl","auth",4);
        LibraryRunner lrObj = new LibraryRunner();
        ArrayList<Object> objList = new ArrayList<Object>();
        objList.add(libObj);
        objList.add(bkObj);
        objList.add(lrObj);
        
        for (Object obj: objList) {
            Class cls = obj.getClass();
            System.out.println("getClass()");
            System.out.println(cls.getName());
            System.out.println ("getConstructors()");
            Constructor<?>[] publicConstructors = cls.getConstructors();
            System.out.println(Arrays.toString(publicConstructors));
            Method[] methods = cls.getMethods(); 
            System.out.println("getMethods()");
            System.out.println(Arrays.toString(methods));
            System.out.println("");
        }

    } 
} 