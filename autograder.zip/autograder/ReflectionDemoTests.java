// A simple Java program to demonstrate the use of reflection 
import java.lang.reflect.Method; 
import java.lang.reflect.Field; 
import java.lang.reflect.Constructor;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.ArrayList;

public class ReflectionDemoTests
{ 
    public static void main(String args[]) throws Exception 
    { 
        Library libObj = new Library();
        Book bkObj = new Book("tl","auth",4);
        LibraryRunner lrObj = new LibraryRunner();
        ArrayList<Object> objList = new ArrayList<Object>();
        objList.add(libObj);
        objList.add(bkObj);
        objList.add(lrObj);
        
//         for (Object obj: objList) {
//             Class cls = obj.getClass();
//             System.out.println("getClass()");
//             System.out.println(cls.getName());
//             System.out.println ("getConstructors()");
//             Constructor<?>[] publicConstructors = cls.getConstructors();
//             System.out.println(Arrays.toString(publicConstructors));
//             Method[] methods = cls.getMethods(); 
//             System.out.println("getMethods()");
//             System.out.println(Arrays.toString(methods));
//             System.out.println("");
//         }
        
        Method lrMain = lrObj.getClass().getDeclaredMethod("main", String[].class);
        String[] params = null; // init params accordingly
        lrMain.invoke(null, (Object) params);
        
//         String line = (Arrays.toString(bkObj.getClass().getMethods()));
//         line = line.replace("[","");
//         line = line.replace("]","");
//         System.out.println(line.getClass().getSimpleName());
//         String[] cons = line.split(", ");
//         System.out.println(Arrays.toString(cons));
//         System.out.println(bkObj.getClass().getName());
//         System.out.println(Arrays.asList(Arrays.toString(bkObj.getClass().getConstructors())).contains("public Book(java.lang.String,java.lang.String,int)"));
//         try {
//             lib lr = new lib();
//         }     
//         catch(Exception e) {
//             System.out.println("doesn't exist");
//         }  

    } 
} 