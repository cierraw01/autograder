import java.io.*;
import java.util.*;
import java.util.jar.*;
import java.nio.file.*;
import java.util.zip.*;

public class JarTasks {

   ArrayList<Submission> labSubmissions;
   
   public JarTasks(){
   
   }
   
   // prints files in current directory  
   public static void listDir() throws IOException{
      DirectoryStream<Path> stream = null;
      try{
         Path dir = Paths.get("./");
         stream = Files.newDirectoryStream(dir, "*.*");
         for (Path p: stream) {
            System.out.println(p.getFileName());
         }
      } catch (IOException ex) {
         ex.printStackTrace();
      }finally{
         stream.close();
      }
   }
   
   // prints the files in the a zip folder
   public void zipList(String zipFilename) throws IOException
   {
   
      ZipFile zipFile = new ZipFile(zipFilename);
      
      ZipEntry zipEntry = zipFile.getEntry("file1.txt");
      
      Enumeration<? extends ZipEntry> entries = zipFile.entries();
   
      while(entries.hasMoreElements()){
         ZipEntry entry = entries.nextElement();
         if(entry.isDirectory()){
            System.out.println("dir  : " + entry.getName());
         } else {
            System.out.println("file : " + entry.getName());
         }
      }      
   }
   
   // Puts students' files into their own sub directories and returns arraylist of student submissions
   public ArrayList<Submission> zipBurst(String zipFilename) throws IOException
   {   
      // declare arraylist of submissions
      ArrayList<Submission> labs = new ArrayList<Submission>();
      
      // Establish a destination directory called S as subdirectory from current location
      String destDirectory = "./S/";
      String destFileName = "";
      File destDir = new File(destDirectory);
      if (!destDir.exists()) {
         destDir.mkdir();
      }
      
      // create empty Submission to cycle through
      Submission lastSubmission = new Submission();
      lastSubmission.setStudentName("");
   
      
      // Get the list of files(entries) in the zip file
      ZipFile zipFile = new ZipFile(zipFilename);
      Enumeration<? extends ZipEntry> entries = zipFile.entries();
      
      // Step through all the files(elements) in the zipfile
      while(entries.hasMoreElements()) {
         ZipEntry entry = entries.nextElement();
         String entryName = entry.getName();
         
         // Shouldn't have any directories, but if it does report it.
         if(entry.isDirectory()) {
            System.out.println("dir  : " + entryName);
         }
         else {
            // declare student name from the file name
            String nameField = entryName.substring(0, entryName.indexOf("_"));
            
            // student directory is made from their name + "_dir"
            // if student directory doesn't exist, create one
            destFileName = ""+destDirectory+nameField + "_dir";
            destDir = new File(destFileName);
            if (!destDir.exists()) {
               destDir.mkdir();
            }
           
            // declare file to add to student's submission and directory files
            String labName = entryName.substring(entryName.lastIndexOf("_")+1);
            if (labName.contains("-") && labName.contains(".java")) {
               labName = labName.substring(0, labName.lastIndexOf("-")) + ".java";            
            }
            
            // create new submission obj if one for the student doesn't already exist
            // if one already does, then just add file to that submission obj
            if (!lastSubmission.getStudentName().equals(nameField)) {
               labs.add(lastSubmission);                       // add prev submission to arraylist of submissions
               Submission newSubmission = new Submission();    // establish a new submission
               newSubmission.setStudentName(nameField);        // give the submission the student's name
               newSubmission.setDirectory(destDir.getAbsolutePath());       // give the submission the directory 
               newSubmission.addFiles(labName);                // add current file's name to the submission's arraylist of files
               lastSubmission = newSubmission;                 // move on from prev submission to the current student's submission
            }
            else {
               lastSubmission.addFiles(labName);               // add current file's name to the submission's arraylist of files
            }
            
            // put the current file in the student's subdirectory
            destFileName += File.separator + labName;
            if (lastSubmission.getStudentName() != null){
               extractEntry(entry, zipFile.getInputStream(entry), destFileName); 
            }            
         }
      }
      
      // add prev submission to arraylist of submissions and del first empty submission placeholder
      labs.add(lastSubmission);
      labs.remove(0);
      
      // return submission arraylist
      return labs;
      
   }
    
    //
   private static final int BUFFER_SIZE = 8192;

   /**
    * List the contents of the specified zip file
    * @param filename
    * @return ArrayList of submission objects
    * @throws IOException
    * @throws URISyntaxException
    */

    /* * Utility method to read data from InputStream*/
   private static void extractEntry(final ZipEntry entry, InputStream is, String extractedFile) throws IOException
   {
      FileOutputStream fos = null;
      fos = new FileOutputStream(extractedFile);
      try {
         final byte[] buf = new byte[BUFFER_SIZE];
         int read = 0;
         int length;
         while ((length = is.read(buf, 0, buf.length)) >= 0)
         {
            fos.write(buf, 0, length);
         } 
      } catch (IOException ioex) { fos.close(); }
   }
   
}