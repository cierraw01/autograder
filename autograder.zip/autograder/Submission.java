import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.Enumeration;



// A submission directory for each student
public class Submission
{

   String studentName;
   String directory;
   ArrayList<String> files;

   public Submission()
   {
      files = new ArrayList<String>();
   }
   public void setStudentName(String n)
   {
      studentName = n;
   }
   public void setDirectory(String n)
   {
      directory = n;
   }
   public void addFiles(String f)
   {
      files.add(f);
   }
   public String getStudentName()
   {
      return studentName;
   }
   public String getDirectory()
   {
      return directory;
   }
   
   public String toString()
   {
      String msg = "" + studentName + " - dir :" + directory + ": files :";
      for (String fn : files)
         msg += fn + ", ";
      msg += "//";
      return msg;
   }


}