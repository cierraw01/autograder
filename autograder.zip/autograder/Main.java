import java.io.*;
import java.util.*;
import java.lang.reflect.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.*;

class Main {
   public static void main (String[] args) throws IOException, InterruptedException {
   
      // Set System to print to txt file "TestSubmissionResults.txt"
      FileOutputStream f = new FileOutputStream("TestSubmissionResults.txt");
      System.setOut(new PrintStream(f));
   
      // Current directory and zip folder of blend files
      String dir = "C:/Users/patri/Documents/computer_science/autograder/";
      String blendZip = "290224_Library_submissions.zip";
      
      // Text input file for student assignment
      String demo = "demo.txt";
      
//       // Java reflection files
       String reflClassesMethods = "ReflectionClassesMethods.java";
       String reflMainMethod = "ReflectionMainMethod.java";
//       String reflDemoTests = "ReflectionDemoTests.java";
//       
//       // Text files of what the reflection files should output
//       String reflClassesMethodsTxt = "reflClassesMethodsOutput.txt";
//       String reflMainMethodTxt = "reflMainMethodOutput.txt";
//       String reflDemoTestsTxt = "reflDemoTestsOutput.txt";
      
      // Initialize JarTasks and ProcessLab Objects
      JarTasks jt = new JarTasks();
      ProcessLab pl = new ProcessLab();
      
      // Initialize ArrayList of student submissions 
      ArrayList<Submission> labs = null;
      
      // separate students' labs into subdirectories and put submission info into arraylist
      labs = jt.zipBurst(blendZip);
      
      // Print array list of student submissions
      for(Submission lab: labs) {
         System.out.println(lab);
      }
      
      // Copy demo and the reflection files into each subdirectory
      pl.moveFileIntoSubdir(labs, dir, demo);
      pl.moveFileIntoSubdir(labs, dir, reflClassesMethods);
      pl.moveFileIntoSubdir(labs, dir, reflMainMethod);
      
      
      // Return boolean for the reflection files output
      // Uses alexhamilton's submission as a comparison
      // Comparing classes and methods is still a little wonky
      String alex_dir = labs.get(0).getDirectory();
      String alex_output = pl.getOutput(alex_dir, reflMainMethod);
      String alex_classmethods_output = pl.getOutput(alex_dir, reflClassesMethods);
      String mainOutput = "";
      String classesMethodsOutput = "";
      for(Submission lab: labs) {
         String labDir = lab.getDirectory();
         mainOutput = pl.getOutput(labDir, reflMainMethod);
         System.out.println(lab.getStudentName());
         System.out.println("Compare main method:");
         System.out.println(pl.getComparison(alex_output, mainOutput));
         classesMethodsOutput = pl.getOutput(labDir, reflClassesMethods);         
         System.out.println("Compare classes and methods:"); 
         System.out.println(pl.getComparison(alex_classmethods_output, classesMethodsOutput));         
      }
   }


}