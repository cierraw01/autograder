import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class Library {

	//ArrayList instance variable that can store Book references
	private ArrayList<Book> books;
	
	/**
	 * Initializes a Library from a text file in the format
	 * # of Books
	 * Title Author Rating
	 * ...
	 * 
	 * Fields must be tab delimited. First line of the file is the number of entries
	 * that follow.
	 * 
	 * @param filename text file to read
	 * @throws FileNotFoundException
	 */
	public Library(String filename) throws FileNotFoundException
	{
		File top100 = new File(filename);
		Scanner topReader = new Scanner(top100);
		
		//instantiate ArrayList
		books = new ArrayList<Book>();
      
		//We need 2 Scanners to read the file because it is tab delimited.
		//The first Scanner reads an entire line and feeds it into the second.
		//The second Scanner can then parse the line on tabs.
		while (topReader.hasNextLine()) {
			Scanner lineReader = new Scanner(topReader.nextLine()).useDelimiter("\\t");

			String title, author;
			int rating;

			if (lineReader.hasNext()) {
				title = lineReader.next();
			} else {
				continue;
			}

			if (lineReader.hasNext()) {
				author = lineReader.next();
			} else {
				continue;
			}

			if (lineReader.hasNextInt()) {
				rating = lineReader.nextInt();
			} else {
				continue;
			}
			addBook(new Book(title, author, rating));
		}
	}
	
	//TODO complete default constructor
	public Library()
	{
		books = new ArrayList<Book>();
	}
	
	//TODO complete initialization constuctor
	public Library(ArrayList<Book> b)
	{
		books = new ArrayList<Book>();
      for (Book book : b)
      {
         books.add(book);
      }
	}

	//initialization constructor
	public Library(Library other)
	{
      books = new ArrayList<Book>();
		ArrayList<Book> otherBooks = other.getBooks();
      setBooks(otherBooks);
      
	}

	//TODO get the union of two ArrayLists
	public Library union(Library other)
	{
      ArrayList<Book> otherBooks = other.getBooks();
      ArrayList<Book> combinedBooks = new ArrayList<Book>();
      
      // for (Book otherBook : otherBooks)
//       {
//          combinedBooks.add(otherBook);
//       }
//       
//       for (Book book : books)
//       {
//          combinedBooks.add(book);
//       }
      combinedBooks.addAll(books);
      combinedBooks.addAll(otherBooks);
      Library combined = new Library(combinedBooks);
		return combined;
	}
	
   //TODO complete modifier method for instance variable books
   public void setBooks(ArrayList<Book> b)
   {
      books.clear();
      for (int i = 0; i < b.size(); i++)
      {
         books.add(b.get(i));
      }
      
   }
   
	//TODO complete accessor for instance variable books
	public ArrayList<Book> getBooks()
	{
		return books;
	}
	
	//TODO complete method to get book at a specified index   
   public Book getBook(int index)
   {
      return books.get(index);
   }
   
	//TODO complete method to set book at a specified index
   public void setBook(int index, Book b)
   {
      books.set(index, b);
   }   
   
	//TODO complete method to add a book at the end of the books ArrayList
	public void addBook(Book addMe)
	{
		books.add(addMe);
	}

	//TODO complete method to add entire ArrayList paramter to end of the books ArrayList
	public void addBooks(ArrayList<Book> addUs)
	{
		for (Book addBook : addUs)
      {
         books.add(addBook);
      }
	}
   
   //TODO complete method to remove book at specified index
   public Book removeBook(int index)
   {
      Book removedBook = books.remove(index);
      return removedBook;
   }
   
	//TODO complete method to remove first instance of a specified book   
   public boolean removeBook(Book b)
   {
      boolean found = books.remove(b);
      return found;
   }
	
	//TODO complete method to check for a book in the books instance variable
	public boolean contains(Book findMe)
	{
		return books.contains(findMe);
	}
   
	//TODO complete method to get index of specified book
   public int indexOf(Book b)
   {
      int index = books.indexOf(b);
      return index;
   }   
	
	//TODO complete method to return a Library containing all books with specified title
	public Library searchByTitle(String title)
	{
      ArrayList<Book> foundBooks = new ArrayList<Book>();
      for (Book book : books)
      {
         boolean found = book.titleContains(title);
         if (found)
         {
            foundBooks.add(book);
         }
      }
      Library library = new Library(foundBooks);
		return library;
	}
	
	//TODO complete method to return a Library containing all books with specified author
	public Library searchByAuthor(String author)
	{
		ArrayList<Book> foundBooks = new ArrayList<Book>();
      for (Book book : books)
      {
         boolean found = book.authorContains(author);
         if (found)
         {
            foundBooks.add(book);
         }
      }
      Library library = new Library(foundBooks);
		return library;
	}

	/**
	 * Find all books with an equal or greater rating.
	 * 
	 * @param rating
	 * @return array of all books with an equal or better rating
	 */
	public Library searchByRating(int rating)
	{
      ArrayList<Book> ratedBooks = new ArrayList<Book>();
      for (Book book : books)
      {
         int bookRating = book.getRating();
         if (bookRating >= rating)
         {
            ratedBooks.add(book);
         }
      }
      Library library = new Library(ratedBooks);
		return library;
	}
   
 	//TODO complete equals method
   public boolean equals(Object obj)
   {
      Library otherLibrary = (Library) obj; 
      if (books.size() != otherLibrary.getBooks().size())
      {
         return false;
      }
      
      for (int i = 0; i < books.size(); i++)
      {
         if (!books.get(i).equals(otherLibrary.getBook(i)))
         {
            return false;
         }
         
      } 
      
      return true;
   }
	
	//TODO complete toString method
	public String toString()
	{
		return books.toString();
	}
}