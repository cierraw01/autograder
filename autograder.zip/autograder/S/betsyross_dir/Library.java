import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class Library {

	//ArrayList instance variable that can store Book references
	private ArrayList<Book> books;
	
	/**
	 * Initializes a Library from a text file in the format
	 * # of Books
	 * Title Author Rating
	 * ...
	 * 
	 * Fields must be tab delimited. First line of the file is the number of entries
	 * that follow.
	 * 
	 * @param filename text file to read
	 * @throws FileNotFoundException
	 */
	public Library(String filename) throws FileNotFoundException
	{
		File top100 = new File(filename);
		Scanner topReader = new Scanner(top100);
		
		//instantiate ArrayList
		books = new ArrayList<Book>();
      
		//We need 2 Scanners to read the file because it is tab delimited.
		//The first Scanner reads an entire line and feeds it into the second.
		//The second Scanner can then parse the line on tabs.
		while (topReader.hasNextLine()) {
			Scanner lineReader = new Scanner(topReader.nextLine()).useDelimiter("\\t");

			String title, author;
			int rating;

			if (lineReader.hasNext()) {
				title = lineReader.next();
			} else {
				continue;
			}

			if (lineReader.hasNext()) {
				author = lineReader.next();
			} else {
				continue;
			}

			if (lineReader.hasNextInt()) {
				rating = lineReader.nextInt();
			} else {
				continue;
			}
			addBook(new Book(title, author, rating));
		}
	}
	
	//default constructor
	public Library()
	{
	books = new ArrayList<Book>();
	}
	
	//initialization constuctor
	public Library(ArrayList<Book> b)
	{
	books = new ArrayList<Book>();
   for(int i=0; i<b.size();i++)
   {
   books.add(b.get(i));
   }
	}

	//initialization constructor
	public Library(Library other)
	{
		books = new ArrayList<Book>();
      setBooks(other.getBooks());
	}

	//get the union of two ArrayLists
	public Library union(Library other)
	{
        ArrayList<Book> newBooks = other.getBooks();
        addBooks(newBooks);
        Library newLibrary = new Library(books);
        return newLibrary;
	}
	
   //modifier method for instance variable books
   public void setBooks(ArrayList<Book> b)
   {
   books.clear();
   for(Book newBook: b)
   {
   books.add(newBook);
   }
   }
   
	//accessor for instance variable books
	public ArrayList<Book> getBooks()
	{
		return books;
	}
	
	//method to get book at a specified index   
   public Book getBook(int index)
   {
   if(books.size() > index)
   {
   Book newBook = books.get(index);
   return newBook;
   }
   else
   return null;
   }
   
	//method to set book at a specified index
   public void setBook(int index, Book b)
   {
      books.add(index, b);
   }   
   
	//method to add a book at the end of the books ArrayList
	public void addBook(Book addMe)
	{
		books.add(addMe);
	}

	//method to add entire ArrayList paramter to end of the books ArrayList
	public void addBooks(ArrayList<Book> addUs)
	{
	for(Book newBook: addUs)
   {
   books.add(newBook);
   }
	}
   
   //method to remove book at specified index
   public Book removeBook(int index)
   {
      Book newBook = books.remove(index);
      return newBook;
   }
   
	//method to remove first instance of a specified book   
   public boolean removeBook(Book b)
   {
      return books.remove(b);
   }
	
	//method to check for a book in the books instance variable
	public boolean contains(Book findMe)
	{
		return books.contains(findMe);
	}
   
	//method to get index of specified book
   public int indexOf(Book b)
   {
      return books.indexOf(b);
   }   
	
	//method to return a Library containing all books with specified title
	public Library searchByTitle(String title)
	{
      ArrayList<Book> allTitle = new ArrayList<Book>();
      for(Book newBook: books)
      {
      if(newBook.titleContains(title))
      {
      allTitle.add(newBook);
      }
      }
      Library newLibrary = new Library(allTitle);
      return newLibrary;
	}
	
	//method to return a Library containing all books with specified author
	public Library searchByAuthor(String author)
	{
		ArrayList<Book> allAuthor = new ArrayList<Book>();
      for(Book newBook: books)
      {
      if(newBook.authorContains(author))
      {
      allAuthor.add(newBook);
      }
      }
      Library newLibrary = new Library(allAuthor);
      return newLibrary;
   }

	/**
	 * Find all books with an equal or greater rating.
	 * 
	 * @param rating
	 * @return array of all books with an equal or better rating
	 */
	public Library searchByRating(int rating)
	{
		ArrayList<Book> allRating = new ArrayList<Book>();
      for(Book newBook: books)
      {
      if(newBook.getRating() >= rating)
      {
      allRating.add(newBook);
      }
      }
      Library newLibrary = new Library(allRating);
      return newLibrary;
	}
   
 	//equals method
   public boolean equals(Object obj)
   {
      
      return books.equals(((Library)obj).getBooks());
   }
	
	//toString method
	public String toString()
	{
		return books.toString();
	}
}