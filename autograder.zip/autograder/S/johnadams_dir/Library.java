import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class Library {

	//ArrayList instance variable that can store Book references
	private ArrayList<Book> books;
	
	/**
	 * Initializes a Library from a text file in the format
	 * # of Books
	 * Title Author Rating
	 * ...
	 * 
	 * Fields must be tab delimited. First line of the file is the number of entries
	 * that follow.
	 * 
	 * @param filename text file to read
	 * @throws FileNotFoundException
	 */
	public Library(String filename) throws FileNotFoundException
	{
		File top100 = new File(filename);
		Scanner topReader = new Scanner(top100);
		
		//instantiate ArrayList
		books = new ArrayList<Book>();
      
		//We need 2 Scanners to read the file because it is tab delimited.
		//The first Scanner reads an entire line and feeds it into the second.
		//The second Scanner can then parse the line on tabs.
		while (topReader.hasNextLine()) {
			Scanner lineReader = new Scanner(topReader.nextLine()).useDelimiter("\\t");

			String title, author;
			int rating;

			if (lineReader.hasNext()) {
				title = lineReader.next();
			} else {
				continue;
			}

			if (lineReader.hasNext()) {
				author = lineReader.next();
			} else {
				continue;
			}

			if (lineReader.hasNextInt()) {
				rating = lineReader.nextInt();
			} else {
				continue;
			}
			addBook(new Book(title, author, rating));
		}
	}
	
	//complete default constructor
	public Library()
	{
		books = new ArrayList<Book>();
	}
	
	//complete initialization constuctor
	public Library(ArrayList<Book> b)
	{
		books = new ArrayList<Book>();
      books.addAll(b);
	}

	//initialization constructor
	public Library(Library other)
	{
		books = new ArrayList<Book>();
      books.addAll(other.getBooks());
	}

	//get the union of two ArrayLists
	public Library union(Library other)
	{
      books.addAll(other.getBooks());
      Library newLibrary = new Library(books);
      
		return newLibrary;
	}
	
   //complete modifier method for instance variable books
   public void setBooks(ArrayList<Book> b)
   {
      books.clear();
      books.addAll(b);
   }
   
	//complete accessor for instance variable books
	public ArrayList<Book> getBooks()
	{
		return books;
	}
	
	//complete method to get book at a specified index   
   public Book getBook(int index)
   {
      return books.get(index);
   }
   
	//complete method to set book at a specified index
   public void setBook(int index, Book b)
   {
      books.add(index, b);
   }   
   
	//complete method to add a book at the end of the books ArrayList
	public void addBook(Book addMe)
	{
		books.add(addMe);
	}

	//complete method to add entire ArrayList paramter to end of the books ArrayList
	public void addBooks(ArrayList<Book> addUs)
	{
		books.addAll(addUs);
	}
   
   //complete method to remove book at specified index
   public Book removeBook(int index)
   {
      Book toReturn = books.remove(index);
      return toReturn;
   }
   
	//complete method to remove first instance of a specified book   
   public boolean removeBook(Book b)
   {
      int p = books.indexOf(b);
      if (p >= 0)
      {
         books.remove(p);
         return true;
      }
      else
      {
         return false;
      }
   }
	
	//complete method to check for a book in the books instance variable
	public boolean contains(Book findMe)
	{
      return books.contains(findMe);
  	}
   
	//complete method to get index of specified book
   public int indexOf(Book b)
   {
      return books.indexOf(b);
   }   
	
	//complete method to return a Library containing all books with specified title
	public Library searchByTitle(String title)
	{
      Library temp1 = new Library();
      
      for (int j = 0; j < books.size(); j++)
      {
         if (books.get(j).titleContains(title))
         {
            temp1.addBook(books.get(j));
         }
      }
      
		return temp1;
	}
	
	//complete method to return a Library containing all books with specified author
	public Library searchByAuthor(String author)
	{
      Library temp2 = new Library();
      
      for (int q = 0; q < books.size(); q++)
      {
         if (books.get(q).authorContains(author))
         {
            temp2.addBook(books.get(q));
         }
      }
      
		return temp2;
	}

	/**
	 * Find all books with an equal or greater rating.
	 * 
	 * @param rating
	 * @return array of all books with an equal or better rating
	 */
	public Library searchByRating(int rating)
	{
      Library temp3 = new Library();
      
      for (int z = 0; z < books.size(); z++)
      {
         if (books.get(z).getRating() >= rating)
         {
            temp3.addBook(books.get(z));
         }
      }
      
		return temp3;
	}
   
 	//complete equals method
   public boolean equals(Object obj)
   {
      Library temp4 = (Library)obj;
      
      if (books.size() == temp4.getBooks().size())
      {
         for (int c = 0; c < temp4.getBooks().size(); c++)
         {
            if (books.get(c).equals(temp4.getBook(c)))
            {
               return true;
            }
         }
      }
      
      return false;
   }
	
	//complete toString method
	public String toString()
	{
		return "" + books;
	}
}