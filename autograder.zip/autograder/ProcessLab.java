import java.io.*;
import java.nio.file.*;
import java.lang.*;
import java.util.*;
import java.nio.*;

public class ProcessLab
{

   public ProcessLab() {
   
   }
   
   // Returns string of a txt file
   public String getText(String file) throws FileNotFoundException {
      Scanner in = new Scanner(new File(file));
      String template = "";
      String ln = "";
      while(in.hasNextLine()) {
         ln = in.nextLine();
         template = template + ln + "\n";
      }
      in.close();
      return template;
   }
   
   // Returns string of running a java file
   public String getOutput(String stringDir, String mainJava) throws IOException, InterruptedException, FileNotFoundException {
      String commandComp = "javac " + stringDir + mainJava;
      String command = "java " + stringDir + mainJava;
      File dir = new File(stringDir);
      Process comp = Runtime.getRuntime().exec(commandComp, null, dir);  
      comp.waitFor();    
      Process pro = Runtime.getRuntime().exec(command, null, dir);
      BufferedReader stdInput = new BufferedReader(new InputStreamReader(pro.getInputStream()));
      String s = null;
      String submissionOutput = "";
      while ((s = stdInput.readLine()) != null) {
         submissionOutput = submissionOutput + s + "\n";    
      }
      return submissionOutput;
   }
   
   // Return boolean value comparing two strings
   public boolean getComparison(String template, String outputFile) {
      String longerStr = "";
      String shorterStr = "";
      String[] templateLines = template.split("\r\n|\r|\n");
      System.out.println(" lines: " + templateLines.length);
      String[] outLines = outputFile.split("\r\n|\r|\n");
      System.out.println(" lines: " + outLines.length);
      boolean comp = template.equals(outputFile);
      
      if (templateLines.length > outLines.length) {
         longerStr = template;
         shorterStr = outputFile;
      }
      else {
         
      }
      int i, j;
      String x;
      boolean b;
      if (!comp){
         for (i = 0; i < templateLines.length; i++) {
            x = templateLines[i];
            b = false;
            for (j = 0; j < outLines.length; j++) {
               if (x.equals(outLines[j])) {
                  b = true;
               }
            }
            if(!b) {
               System.out.println("missing line: " + x);
            }
         }
      }
      return comp;
   }
   
   // Move source file into each student subdirectory 
   public void moveFileIntoSubdir(ArrayList<Submission> labs, String srcDir, String srcFile) {
      Path srcPath = Paths.get(srcDir + srcFile);
      for (Submission lab: labs) {
         System.out.println(lab.getStudentName());
         String stringDir = lab.getDirectory();
         stringDir = stringDir.replace("\\","/");
         stringDir = stringDir.replace("./","");
         stringDir = stringDir + "/";         
         lab.setDirectory(stringDir);
         String destString = (stringDir + srcFile).replace("//", "/");
         Path dest = Paths.get(destString);    
         try {
            Files.copy(srcPath, dest);
         } catch (IOException e) {
             // System.out.println("Couldn't move " + srcFile + " to " + destString);
         }
      }
   }
}



