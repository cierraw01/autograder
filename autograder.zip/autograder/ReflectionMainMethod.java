// A simple Java program to demonstrate the use of reflection 
import java.lang.reflect.Method; 
import java.lang.reflect.Field; 
import java.lang.reflect.Constructor;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.ArrayList;

public class ReflectionMainMethod
{ 
    public static void main(String args[]) throws Exception 
    { 
        Library libObj = new Library();
        Book bkObj = new Book("tl","auth",4);
        LibraryRunner lrObj = new LibraryRunner();
        ArrayList<Object> objList = new ArrayList<Object>();
        objList.add(libObj);
        objList.add(bkObj);
        objList.add(lrObj);
        
        Method lrMain = lrObj.getClass().getDeclaredMethod("main", String[].class);
        String[] params = null;
        lrMain.invoke(null, (Object) params);

    } 
} 